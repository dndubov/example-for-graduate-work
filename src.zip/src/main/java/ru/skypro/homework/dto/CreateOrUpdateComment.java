package ru.skypro.homework.dto;

import lombok.Data;

@Data
public class CreateOrUpdateComment {

    private String text;
}
