package ru.skypro.homework.dto;

public enum Role {
    USER, ADMIN
}
